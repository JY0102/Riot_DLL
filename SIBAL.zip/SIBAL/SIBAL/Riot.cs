﻿using Newtonsoft.Json;
using Riot.Contracts;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Text.RegularExpressions;
using Match = Riot.Contracts.Match;

namespace Riot
{
    public class OpenApi : RiotTable
    {
        public List<Match> Matches = new List<Match>();

        private string API_KEY = string.Empty;
        public string My_Puuid = string.Empty;

        public void AddKey(string key)
        {
            API_KEY = key;
        }

        #region JSON PARSING

        private string SearchPuuid(string gameName, string tagLine)
        {
            try
            {
                string url = $"https://asia.api.riotgames.com/riot/account/v1/accounts/by-riot-id/{gameName}/{tagLine}";

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

                request.Headers.Add("Accept-Language", "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7");
                request.Headers.Add("Accept-Charset", "application/x-www-form-urlencoded; charset=UTF-8");
                request.Headers.Add("X-Riot-Token", API_KEY);

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                if (response.StatusCode != HttpStatusCode.OK)
                    throw new Exception($"{response.StatusCode}");

                // 응답 본문 읽기
                using (Stream stream = response.GetResponseStream())
                {
                    using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                    {
                        string responseText = reader.ReadToEnd();

                        var temp = JsonConvert.DeserializeObject<Dictionary<string, string>>(responseText);
                        return temp["puuid"];
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Search Error : " + ex.Message);
            }
        }
        private List<string> SearchMatch(string puuid, string type, int count)
        {
            try
            {
                string url = $"https://asia.api.riotgames.com/lol/match/v5/matches/by-puuid/{puuid}/ids";

                url += $"?type={type}"; // normal , ranked
                url += "&start=0";
                url += $"&count={count}";
                url += $"&api_key={API_KEY}";

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

                request.Headers.Add("Accept-Language", "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7");
                request.Headers.Add("Accept-Charset", "application/x-www-form-urlencoded; charset=UTF-8");
                request.Headers.Add("Origin", "https://developer.riotgames.com");

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                if (response.StatusCode != HttpStatusCode.OK)
                    throw new Exception($"{response.StatusCode}");

                using (Stream stream = response.GetResponseStream())
                {
                    using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                    {
                        string responseText = reader.ReadToEnd();

                        return JsonConvert.DeserializeObject<List<string>>(responseText);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($" SEARCH MATCH v5 : {ex.Message}");
            }

        }
        private Dictionary<string, object> MatchData(string matchid)
        {
            try
            {
                string url = $"https://asia.api.riotgames.com/lol/match/v5/matches/{matchid}";

                url += $"?api_key={API_KEY}";

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

                request.Headers.Add("Accept-Language", "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7");
                request.Headers.Add("Accept-Charset", "application/x-www-form-urlencoded; charset=UTF-8");
                request.Headers.Add("Origin", "https://developer.riotgames.com");

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                if (response.StatusCode != HttpStatusCode.OK)
                    throw new Exception($"{response.StatusCode}");

                using (Stream stream = response.GetResponseStream())
                {
                    using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                    {
                        string responseText = reader.ReadToEnd();

                        return JsonConvert.DeserializeObject<Dictionary<string, object>>(responseText);
                    }
                }

            }
            catch (Exception ex)
            {
                throw new Exception($" MATCH v5 ERROR : {ex.Message}");
            }
        }
        private Match Make_Match(object info)
        {
            return JsonConvert.DeserializeObject<Match>(info.ToString());
        }
        private List<Tier> GetTier(string puuid)
        {
            try
            {
                string url = $"https://kr.api.riotgames.com/lol/league/v4/entries/by-puuid/{puuid}";

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

                request.Headers.Add("Accept-Language", "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7");
                request.Headers.Add("Accept-Charset", "application/x-www-form-urlencoded; charset=UTF-8");
                request.Headers.Add("Origin", "https://developer.riotgames.com");
                request.Headers.Add("X-Riot-Token", API_KEY);

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                if (response.StatusCode != HttpStatusCode.OK)
                    throw new Exception($"{response.StatusCode}");

                using (Stream stream = response.GetResponseStream())
                {
                    using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                    {
                        string responseText = reader.ReadToEnd();

                        return JsonConvert.DeserializeObject<List<Tier>>(responseText);
                    }
                }

            }
            catch (Exception ex)
            {
                throw new Exception($" LeagueV4 ERROR : {ex.Message}");
            }


        }

        #endregion

        /// <summary>
        /// OpenApi 에서 데이터를 검색
        /// </summary>
        /// <param name="gameName"> 닉네임#태그 </param>
        /// <param name="type"> 노말(normal) , 랭크(ranked) </param>
        /// <param name="count"> 전적 검색할 개수 </param>
        /// <returns> JSON형식으로 저장된 정보들 </returns>
        ///
        public List<Match> Search(string gameName, string type, int count)
        {
            try
            {
                string[] sp = gameName.Split('#');

                string puuid = SearchPuuid(sp[0], sp[1]);

                // matches 는 matchId 가 있음
                // normal , ranked
                var matches = SearchMatch(puuid, type, count);

                foreach (var matchId in matches)
                {
                    using (var context = new MatchContext())
                    {
                        var match = context.Matches
                            .Include("participants")
                            .Include("participants.Tiers")
                            .Include("teams")
                            .FirstOrDefault(m => m.matchId == matchId);

                        if (match != null)
                        {
                            Matches.Add(match);
                            continue;
                        }
                    }

                    var info = MatchData(matchId)["info"];

                    var matchinfo = Make_Match(info);

                    foreach (var participant in matchinfo.participants)
                    {
                        participant.Tiers = GetTier(participant.puuid);
                    }

                    matchinfo.GameNickName = gameName;
                    matchinfo.matchId = matchId;
                    matchinfo.SetMyPart(puuid);

                    SetImg(matchinfo);

                    Matches.Add(matchinfo);


                    #region DB에 저장
                    using (var context = new MatchContext())
                    {
                        context.Matches.Add(matchinfo);

                        context.SaveChanges();
                    }
                    #endregion
                }

                return Matches;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// JSON 으로 파싱해줌 혹시 모를 디버깅 용
        /// </summary>
        /// <returns></returns>
        public string DebugJson()
        {
            return JsonConvert.SerializeObject(Matches, Newtonsoft.Json.Formatting.Indented);
        }


        public List<Match> SearchGameHistroy(string gameName, string type, int count)
        {
            using (var context = new MatchContext())
            {
                var matches = context.Matches
                    .Include("participants")
                    .Include("participants.Tiers")
                    .Include("teams")
                    .Take(count)
                    .Where(m => m.GameNickName == gameName)
                .ToList();

                return matches;
            }
        }

        private void SetImg(Match matchinfo)
        {
            foreach (var participant in matchinfo.participants)
            {
                participant.championImg = GetChampionByte(participant.championName);

                participant.summoner1Id_Img = GetSpellByte(participant.summoner1Id);
                participant.summoner2Id_Img = GetSpellByte(participant.summoner2Id);

                participant.item0_Img = GetItemByte(participant.item0);
                participant.item1_Img = GetItemByte(participant.item1);
                participant.item2_Img = GetItemByte(participant.item2);
                participant.item3_Img = GetItemByte(participant.item3);
                participant.item4_Img = GetItemByte(participant.item4);
                participant.item5_Img = GetItemByte(participant.item5);
                participant.item6_Img = GetItemByte(participant.item6);

                participant.primaryRune_Img = GetRuneByte(participant.primaryRune);
                participant.subRune_Img = GetRuneByte(participant.subRune);
            }
        }
    }

    public class RiotTable : DataDragon
    {
        public RiotTable()
        {

            if (InItDirectory())
            {
                GetSpellImg(base.DD_VERSION);

                GetRuneImg(base.DD_VERSION);

                GetItemImg(base.DD_VERSION);

                GetChampionImg(base.DD_VERSION);
            }
        }

        #region 폴더 생성 및 딕셔너리 설정

        private enum FileName
        {
            Spell_Img,
            Rune_Img,
            Champion_Img,
            Item_Img
        }

        private const string PATH = @"C:\Riot_Img\";
        public bool InItDirectory()
        {

            string folderPath = PATH;

            // 폴더가 존재하지 않으면 새로 생성
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);


                foreach (var name in Enum.GetNames(typeof(FileName)))
                {
                    folderPath = PATH + name;

                    // 폴더가 존재하지 않으면 새로 생성
                    if (!Directory.Exists(folderPath))
                    {
                        Directory.CreateDirectory(folderPath);
                    }
                }

                return true;
            }
            else
                return false;
        }

        #endregion

        #region ROW 값 추가

        internal void GetRuneImg(string version)
        {
            string url = $"https://ddragon.leagueoflegends.com/cdn/{version}/data/ko_KR/runesReforged.json";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            if (response.StatusCode != HttpStatusCode.OK)
                throw new Exception($"{response.StatusCode}");

            // 응답 본문 읽기
            using (Stream stream = response.GetResponseStream())
            {
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                {
                    string responseText = reader.ReadToEnd();

                    var runes = JsonConvert.DeserializeObject<List<RuneData>>(responseText);

                    SetRuneDirectory(runes);
                }
            }
        }
        internal void SetRuneDirectory(List<RuneData> ruenDatas)
        {
            foreach (var rune in ruenDatas)
            {
                GetRuneUrl(rune.id, rune.icon);

                foreach (var slot in rune.slots)
                {
                    foreach (var runes in slot["runes"])
                    {
                        GetRuneUrl(runes.id, runes.icon);
                    }
                }
            }
        }

        internal void GetSpellImg(string version)
        {
            string url = $"https://ddragon.leagueoflegends.com/cdn/{version}/data/ko_KR/summoner.json";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            if (response.StatusCode != HttpStatusCode.OK)
                throw new Exception($"{response.StatusCode}");

            // 응답 본문 읽기
            using (Stream stream = response.GetResponseStream())
            {
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                {
                    string responseText = reader.ReadToEnd();

                    var spellData = JsonConvert.DeserializeObject<SpellData>(responseText);

                    SetSpellDirectory(spellData);
                }
            }
        }
        internal void SetSpellDirectory(SpellData spellData)
        {
            foreach (var spell in spellData.data)
            {
                GetSpellUrl(spell.Value.key, spell.Key);

            }
        }

        internal void GetItemImg(string version)
        {
            string url = $"https://ddragon.leagueoflegends.com/cdn/{version}/data/ko_KR/item.json";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            if (response.StatusCode != HttpStatusCode.OK)
                throw new Exception($"{response.StatusCode}");

            // 응답 본문 읽기
            using (Stream stream = response.GetResponseStream())
            {
                List<Item> items = new List<Item>();

                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                {
                    string responseText = reader.ReadToEnd();
                    var data = JsonConvert.DeserializeObject<ItemData>(responseText);

                    foreach (var temp in data.data)
                    {
                        temp.Value.Id = temp.Key;
                    }

                    SetItemDirectory(data);
                }
            }
        }
        internal void SetItemDirectory(ItemData items)
        {
            foreach (var item in items.data)
            {
                GetItemUrl(item.Value.img);
            }
        }

        internal void GetChampionImg(string version)
        {
            string url = $"https://ddragon.leagueoflegends.com/cdn/{base.DD_VERSION}/data/ko_KR/champion.json";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            if (response.StatusCode != HttpStatusCode.OK)
                throw new Exception($"{response.StatusCode}");

            // 응답 본문 읽기
            using (Stream stream = response.GetResponseStream())
            {
                List<Item> items = new List<Item>();

                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                {
                    string responseText = reader.ReadToEnd();
                    var champion = JsonConvert.DeserializeObject<Champion>(responseText);

                    SetChampionDirectory(champion);
                }
            }
        }
        internal void SetChampionDirectory(Champion champion)
        {
            foreach (var temp in champion.data)
            {
                GetChampionUrl(temp.Key);
            }
        }

        #endregion

        #region 데이터 테이블 -> 절대경로 -> Byte

        public byte[] GetSpellByte(string Spell_Num)
        {
            using (FileStream picFileStream = new FileStream($@"{PATH}Spell_Img\{Spell_Num}.png", FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                BinaryReader picReader = new BinaryReader(picFileStream);
                return picReader.ReadBytes(Convert.ToInt32(picFileStream.Length));
            }
        }

        public byte[] GetRuneByte(string Rune_Num)
        {
            using (FileStream picFileStream = new FileStream($@"{PATH}Rune_Img\{Rune_Num}.png", FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                BinaryReader picReader = new BinaryReader(picFileStream);
                return picReader.ReadBytes(Convert.ToInt32(picFileStream.Length));
            }
        }

        public byte[] GetChampionByte(string Champion_Name)
        {
            using (FileStream picFileStream = new FileStream($@"{PATH}Champion_Img\{Champion_Name}.png", FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                BinaryReader picReader = new BinaryReader(picFileStream);
                return picReader.ReadBytes(Convert.ToInt32(picFileStream.Length));
            }
        }

        public byte[] GetItemByte(string Item_Num)
        {
            if (Item_Num == "0")
                return null;

            using (FileStream picFileStream = new FileStream($@"{PATH}Item_Img\{Item_Num}.png", FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                BinaryReader picReader = new BinaryReader(picFileStream);
                return picReader.ReadBytes(Convert.ToInt32(picFileStream.Length));
            }
        }


        #endregion
    }

    public class DataDragon
    {
        internal string DD_VERSION = "";

        /// <summary>
        ///  DataDragon 의 버전을 가져옴
        /// </summary>
        /// <exception cref="Exception"></exception>
        public DataDragon()
        {
            InItDataDragonVersion();
        }


        #region 데이터 드래곤 버전 설정

        public void InItDataDragonVersion()
        {
            try
            {
                string url = $"https://ddragon.leagueoflegends.com/api/versions.json";

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                if (response.StatusCode != HttpStatusCode.OK)
                    throw new Exception($"{response.StatusCode}");

                // 응답 본문 읽기
                using (Stream stream = response.GetResponseStream())
                {
                    using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                    {
                        string responseText = reader.ReadToEnd();

                        var version = JsonConvert.DeserializeObject<List<string>>(responseText);
                        DD_VERSION = version[0];
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error : " + ex.Message);
            }
        }

        #endregion

        #region 이미지 절대 경로에 다운로드

        /// <summary>
        /// 아이템 이미지
        /// </summary>
        /// <param name="itemNum"> 아이템 번호 </param>
        /// <returns> 이미지 url </returns>
        public void GetItemUrl(string itemNum)
        {
            string url = $"https://ddragon.leagueoflegends.com/cdn/{DD_VERSION}/img/item/{itemNum}";

            using (WebClient client = new WebClient())
            {
                try
                {
                    byte[] imageBytes = client.DownloadData(url); // 이미지 바이트 배열
                    string folderPath = @"C:\Riot_Img\Item_Img"; // 저장할 경로
                    string fileName = $"{itemNum}";               // 파일 이름

                    string fullPath = Path.Combine(folderPath, fileName);
                    File.WriteAllBytes(fullPath, imageBytes);
                }
                catch (Exception ex)
                {
                    throw new Exception($"GetItemUrl 오류 발생: {ex.Message}");
                }
            }
        }

        /// <summary>
        ///  챔피언 이미지
        /// </summary>
        /// <param name="championName"> 챔피언 이름 ( 영어 ) </param>
        /// <returns> 이미지 url </returns>
        public void GetChampionUrl(string championName)
        {
            string url = $"https://ddragon.leagueoflegends.com/cdn/{DD_VERSION}/img/champion/{championName}.png";

            using (WebClient client = new WebClient())
            {
                try
                {
                    byte[] imageBytes = client.DownloadData(url); // 이미지 바이트 배열
                    string folderPath = @"C:\Riot_Img\Champion_Img"; // 저장할 경로
                    string fileName = $"{championName}.png";               // 파일 이름

                    string fullPath = Path.Combine(folderPath, fileName);
                    File.WriteAllBytes(fullPath, imageBytes);
                }
                catch (Exception ex)
                {
                    throw new Exception($"GetChampionUrl 오류 발생: {ex.Message}");
                }
            }
        }

        /// <summary>
        /// 스펠 이미지
        /// </summary>
        /// <param name="SpellName"> 스펠 이름 (영어) </param>
        /// <returns> 이미지 url </returns>
        public void GetSpellUrl(string id, string SpellName)
        {

            string url = $"https://ddragon.leagueoflegends.com/cdn/{DD_VERSION}/img/spell/{SpellName}.png";

            using (WebClient client = new WebClient())
            {
                try
                {
                    byte[] imageBytes = client.DownloadData(url); // 이미지 바이트 배열
                    string folderPath = @"C:\Riot_Img\Spell_Img"; // 저장할 경로
                    string fileName = $"{id}.png";               // 파일 이름

                    string fullPath = Path.Combine(folderPath, fileName);
                    File.WriteAllBytes(fullPath, imageBytes);
                }
                catch (Exception ex)
                {
                    throw new Exception($"GetSpellUrl 오류 발생: {ex.Message}");
                }
            }
        }

        /// <summary>
        /// 룬 이미지
        /// </summary>
        /// <param name="runeName"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public void GetRuneUrl(string runeId, string runeName)
        {
            string url = $"https://ddragon.leagueoflegends.com/cdn/img/{runeName}";

            using (WebClient client = new WebClient())
            {
                try
                {
                    byte[] imageBytes = client.DownloadData(url); // 이미지 바이트 배열
                    string folderPath = @"C:\Riot_Img\Rune_Img"; // 저장할 경로
                    string fileName = $"{runeId}.png";               // 파일 이름

                    string fullPath = Path.Combine(folderPath, fileName);
                    File.WriteAllBytes(fullPath, imageBytes);
                }
                catch (Exception ex)
                {
                    throw new Exception($"GetRuneUrl 오류 발생: {ex.Message}");
                }
            }
        }

        #endregion
    }
}
