﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.Serialization;
using Newtonsoft.Json;



namespace Riot.Contracts
{

    #region JSON
    public class SpellData
    {
        public Dictionary<string, Spell> data { get; set; }
    }
    public class Spell
    {
        public string key { get; set; }
    }


    public class ItemData
    {
        public Dictionary<string, Item> data { get; set; }

    }
    public class Item
    {

        public string Id { get; set; }

        public Dictionary<string, string> image { get; set; }

        public string img
        {
            get => image["full"];
        }
    }

    public class RuneData
    {
        public string id { get; set; }
        public string icon { get; set; }


        public List<Dictionary<string, List<Rune>>> slots { get; set; }


    }
    public class Rune
    {
        public string id { get; set; }
        public string icon { get; set; }

    }

    public class Champion
    {
        public Dictionary<string, object> data { get; set; }
    }

    #endregion

    public class MatchContext : DbContext
    {
        private const string server_name = "DESKTOP-N7SQTCC\\SQLEXPRESS";
        private const string db_name = "WB41";
        private const string sql_id = "aaa";
        private const string sql_pw = "1234";
        public MatchContext()
            : base($"Server={server_name};Database={db_name};User Id={sql_id};Password={sql_pw};TrustServerCertificate=True;")
        { }

        // 테이블로 매핑할 엔티티
        public DbSet<Match> Matches { get; set; }
    }


    #region 데이터 계약 한 데이터 객체

    [DataContract]
    public class Match
    {
        [DataMember]
        [Key]
        public string matchId { get; set; }

        #region 매치 정보

        [DataMember] public string GameNickName { get; set; }

        [DataMember] private string _queueId = null;
        [DataMember] public string queueId
        {
            get => _queueId;
            set
            {
                switch (value)
                {
                    case "420": _queueId = "솔로랭크"; break;
                    case "440": _queueId = "자유랭크"; break;
                    case "400": _queueId = "일반"; break;
                    case "450": _queueId = "칼바람"; break;
                    default: _queueId = value; break;
                }
            }
        }

        [DataMember] private DateTime _gameEndTimestamp { get; set; }

        [DataMember] public string gameEndTimestamp
        {
            get => _gameEndTimestamp.ToString();
            set
            {
                long timestamp;

                if (long.TryParse(value.ToString(), out timestamp))
                {
                    DateTimeOffset dateTimeOffset = DateTimeOffset.FromUnixTimeMilliseconds(timestamp);
                    _gameEndTimestamp = dateTimeOffset.LocalDateTime;
                }
                else
                {
                    _gameEndTimestamp = DateTime.Parse(value);
                }
            }
        }

        #endregion

        #region 팀 정보

        [DataMember] public List<Team> teams { get; set; }

        [DataMember] public Team blueTeam { get => teams?[0]; }

        [DataMember] public Team redTeam { get => teams?.Count > 1 ? teams[1] : null; }

        #endregion

        #region 참가자들

        [DataMember] public List<Participant> participants { get; set; }

        #endregion

        #region 나의 전적

        [DataMember] public int idx { get; set; } = -1;
        [DataMember] public Participant MyPart
        {
            get
            {
                if (idx != -1 && participants?.Count > idx)
                    return participants[idx];
                return null;
            }
        }
        public void SetMyPart(string puuid)
        {
            if (participants == null) return;

            for (int i = 0; i < participants.Count && i < 10; i++)
            {
                if (participants[i].puuid == puuid)
                    idx = i;

                if (i < 5 && blueTeam != null)
                {
                    decimal teamkill = decimal.Parse(blueTeam.champion ?? "0");
                    decimal kills = decimal.Parse(participants[i].kills ?? "0");
                    decimal assist = decimal.Parse(participants[i].assists ?? "0");

                    decimal percent = (teamkill <= 0 || kills <= 0) ? 0 : (kills + assist) / teamkill;
                    participants[i].killPercent = $"{percent:P0}";
                }
                else if (i >= 5 && redTeam != null)
                {
                    decimal teamkill = decimal.Parse(redTeam.champion ?? "0");
                    decimal kills = decimal.Parse(participants[i].kills ?? "0");
                    decimal assist = decimal.Parse(participants[i].assists ?? "0");

                    decimal percent = (teamkill <= 0 || kills <= 0) ? 0 : (kills + assist) / teamkill;
                    participants[i].killPercent = $"{percent:P0}";
                }
            }
        }

        #endregion
    }

    [DataContract]
    public class Team
    {
        #region 데이터 테이블 PK , FK 설정
        public string MatchId { get; set; }

        [ForeignKey("MatchId")]
        public virtual Match Match { get; set; }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int TeamId { get; set; }
        #endregion




        [DataMember] public Dictionary<string, Dictionary<string, string>> feats
        {
            set
            {
                if (value?.ContainsKey("FIRST_BLOOD") == true &&
                    value["FIRST_BLOOD"]?.ContainsKey("featState") == true &&
                    value["FIRST_BLOOD"]["featState"] == "3")
                {
                    FirstBlood = true;
                    value.Clear();
                }
            }
        }

        #region 퍼블
        [DataMember] public bool FirstBlood { get; set; } = false;
        #endregion

        #region 오브젝트들

        [DataMember] public Dictionary<string, Dictionary<string, string>> objectives
        {
            set
            {
                SetObjectives(value);
            }
        }

        private void SetObjectives(Dictionary<string, Dictionary<string, string>> objs)
        {
            if (objs == null) return;

            foreach (var obj in objs)
            {
                if (!obj.Value.ContainsKey("kills")) continue;

                switch (obj.Key)
                {
                    case "atakhan": atakhan = obj.Value["kills"]; break;
                    case "baron": baron = obj.Value["kills"]; break;
                    case "champion": champion = obj.Value["kills"]; break;
                    case "dragon": dragon = obj.Value["kills"]; break;
                    case "horde": horde = obj.Value["kills"]; break;
                    case "riftHerald": riftHerald = obj.Value["kills"]; break;
                    case "inhibitor": inhibitor = obj.Value["kills"]; break;
                    case "tower": tower = obj.Value["kills"]; break;
                }
            }
        }

        // 프로퍼티

        [DataMember] public string atakhan { get; set; }

        [DataMember] public string baron { get; set; }

        [DataMember] public string champion { get; set; }

        [DataMember] public string dragon { get; set; }

        [DataMember] public string horde { get; set; }

        [DataMember] public string riftHerald { get; set; }

        [DataMember] public string inhibitor { get; set; }

        [DataMember] public string tower { get; set; }
        #endregion
    }

    [DataContract]
    public class Participant
    {
        #region 데이터 테이블 PK , FK 설정
        public string MatchId { get; set; }

        [ForeignKey("MatchId")]
        public virtual Match Match { get; set; }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ParticipantId { get; set; }
        #endregion

        #region 팀 정보

        [DataMember] private string teamName;

        [DataMember]
        public string teamid
        {
            get => teamName;
            set
            {
                if (value == null) return;
                else if(value != "100" || value != "200")
                    teamName = value;
                else
                    teamName = value == "100" ? "블루팀" : "레드팀";
            }
        }

        #endregion

        #region 승리 여부
        [DataMember] public bool win { get; set; }
        #endregion

        #region 챔피언
        [DataMember] public string championName { get; set; }

        //이미지
        [DataMember] public byte[] championImg { get; set; }
        #endregion

        #region 닉네임
        [DataMember] public string GameName { get => $"{riotIdGameName}#{riotIdTagline}"; }

        [DataMember] public string riotIdGameName { get; set; }

        [DataMember] public string riotIdTagline { get; set; }

        #endregion

        #region PUUID
        [DataMember] public string puuid { get; set; }
        #endregion

        #region 스펠

        [DataMember] public string summoner1Id { get; set; }

        [DataMember] public string summoner2Id { get; set; }

        // 이미지

        [DataMember] public byte[] summoner1Id_Img { get; set; }

        [DataMember] public byte[] summoner2Id_Img { get; set; }

        #endregion

        #region 챔피언 레벨
        [DataMember] public string champLevel { get; set; }
        #endregion

        #region 아이템

        [DataMember] public string item0 { get; set; }

        [DataMember] public string item1 { get; set; }

        [DataMember] public string item2 { get; set; }

        [DataMember] public string item3 { get; set; }

        [DataMember] public string item4 { get; set; }

        [DataMember] public string item5 { get; set; }

        [DataMember] public string item6 { get; set; }

        // 이미지

        [DataMember] public byte[] item0_Img { get; set; }

        [DataMember] public byte[] item1_Img { get; set; }

        [DataMember] public byte[] item2_Img { get; set; }

        [DataMember] public byte[] item3_Img { get; set; }

        [DataMember] public byte[] item4_Img { get; set; }

        [DataMember] public byte[] item5_Img { get; set; }
        [DataMember] public byte[] item6_Img { get; set; }

        #endregion

        #region 미니언 개수

        [DataMember] private string _totalMinionsKilled { get; set; }


        [DataMember]
        public string totalMinionsKilled
        {
            get => "CS:" + _totalMinionsKilled;
            set
            {
                if (value.IndexOf("CS") == 0)
                {
                    string[] sp = value.Split(':');

                    _totalMinionsKilled = sp[1];
                }
                else
                    _totalMinionsKilled = value;
            }
        }

        #endregion

        #region 골드량

        [DataMember] private string _goldEarned { get; set; }

        [DataMember]
        public string goldEarned
        {
            get => "골드 : " + _goldEarned;
            set
            {
                if (int.TryParse(value, out int temp))
                    _goldEarned = temp.ToString("N0");
                else if (value != null)
                {
                    if (value.IndexOf("골드") == 0)
                    {
                        string[] sp = value.Split(':');

                        _goldEarned = sp[1];
                    }
                    else
                        _goldEarned = value;
                }
            }
        }

        #endregion

        #region 딜량 , 받은 피해량
        [DataMember] public string totalDamageDealtToChampions { get; set; }
        [DataMember] public string totalDamageTaken { get; set; }

        #endregion

        #region KDA 관련

        [DataMember] private Dictionary<string, object> temp { get; set; }

        [DataMember] public Dictionary<string, object> challenges
        {
            get => temp;

            set
            {
                if (value?.ContainsKey("kda") == true &&
                    double.TryParse(value["kda"].ToString(), out double temp))
                {
                    kda = temp.ToString("F2");
                    value.Clear();
                }
            }
        }

        [DataMember] public string kda { get; set; }

        [DataMember] public string K_D_A { get => $"{kills} / {deaths} / {assists}"; }

        [DataMember] public string kills { get; set; }

        [DataMember] public string deaths { get; set; }

        [DataMember] public string assists { get; set; }

        [DataMember] public string killPercent { get; set; }

        #endregion

        #region 룬

        [DataMember] public object perks
        {
            set => SetRune(value);
        }

        [DataMember] public string primaryRune { get; set; }
        [DataMember] public byte[] primaryRune_Img { get; set; }
        [DataMember] public string subRune { get; set; }
        [DataMember] public byte[] subRune_Img { get; set; }

        public void SetRune(object perk)
        {
            try
            {
                var _perks = JsonConvert.DeserializeObject<Dictionary<string, object>>(perk.ToString());
                var styles = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(_perks["styles"].ToString());

                // 주룬
                var primaryStyle = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(styles[0]["selections"].ToString());

                primaryRune = primaryStyle[0]["perk"].ToString();

                if (primaryRune == null)
                    throw new Exception();

                // 부룬
                var subStyle = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(styles[1]["selections"].ToString());

                subRune += subStyle[1]["perk"].ToString();
                if (subRune == null)
                    throw new Exception();
            }
            catch (Exception)
            {
                // 로깅 처리
                primaryRune = "Unknown";
                subRune = "Unknown";
            }
        }

        #endregion

        #region 티어
        [DataMember] public List<Tier> Tiers { get; set; } = null;

        [DataMember]
        public Tier SoloTiers
        {
            get
            {
                if (Tiers == null) return null;

                foreach (var tier in Tiers)
                {
                    if (tier.queueType == "솔로랭크")
                        return tier;
                }
                return null;
            }
        }

        [DataMember]
        public Tier FlexTiers
        {
            get
            {
                if (Tiers == null) return null;

                foreach (var tier in Tiers)
                {
                    if (tier.queueType == "자유랭크")
                        return tier;
                }
                return null;
            }
        }
        #endregion
    }

    [DataContract]
    public class Tier
    {
        #region 데이터 테이블 PK , FK 설정

        public int ParticipantId { get; set; }

        [ForeignKey("ParticipantId")]
        public virtual Participant Participant { get; set; }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int TierId { get; set; }

        #endregion


        [DataMember] private string _queueType;
        [DataMember] public string queueType
        {
            get => _queueType;
            set
            {
                if (value == null) return;

                switch (value)
                {
                    case "RANKED_SOLO_5x5":
                        _queueType = "솔로랭크";
                        break;
                    case "RANKED_FLEX_SR":
                        _queueType = "자유랭크";
                        break;
                    default:
                        _queueType = value;
                        break;
                }
            }
        }
        [DataMember] public string TierInfo { get => $"{tier} {rank}"; }
        [DataMember] public string tier { get; set; }
        [DataMember] public string rank { get; set; }
        [DataMember] public string wins { get; set; }
        [DataMember] public string losses { get; set; }
    }

    #endregion
}